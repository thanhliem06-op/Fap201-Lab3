`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
b93NPtq2bG9O6ETyJ1kR9DD9K4xT7upI4eHu12PBWxqwN178VCBAN5trkTrsoxX9fjIZp2spxiRC
/A65h2Q7YqOyh9w0oHxZFfAvC5xn9HH90GVkEFP5WNw+fboiQ7jfLc5s4QdD0ybnAsZVKL5FsQJV
KIGqik/wtli63I2RHrsH8lSzduX5WsgxzbEXUjplfWAUV7uffSszjf8Kkheg5WmHFrTtOmwFvaCk
ALZlrSdVFkJUvUFm3SwM5NI7bWzzeiF6Bh4H91nHVzIhDvkdM8wRSTwpnKoKONdvI3PZMmiR/6Xp
bpRJgiv3nGgaxWg0/ux5QVvKOq7yD9lEW+XYPA==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=496)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
kKKv8GAilzy3tlXPzzukj5Bm2xObBxDKG2eNjEJC8rtUj3EdBDxM2nsVdwLdeleD20iHwoPJE7Kk
bpal2b/0Ys7bhkA1XiOoBxKyGhxoKmURS00bEb04f97mCX4w7id8XyOVEhSJrDHWGNM/jn4Df69g
YBOWZ+xoWaP9Ovj+se6vEYbUn2hZvCUr4UUUtLO6NJjNng/RMl8Nm1NjJymWyZC+hGmuH/FBQF5W
RKWBOCuS7ct43f9TSjQGPWH6GdPW5OR0jS6XFyCEfW4uKnJT8kP9T1G3iMC177XpdQbF9EH7lbxj
d76C/4JTXnblxqSc6pgZWaasXt3WvEU9+c+aIch2ByNRBgPzJxgxx05K+EEsVEinMvHg2/fxpt8f
yxYFPHOAFif7ZMXEafSGhWtK4UdrFIZXapqxZHQ7V3tSQX3KgnslSKM32gHLxObENuJVStDyeC0E
INlYDh2fl0ySLOn1b3d0q0G9WACH0OXMoYk8irp3YiwDKwTapJPCyOC84KbLvXDXO8fmmslYK2rc
UUqMxyHzwibhC8CBlQSNi5C3PWU4DKVh4uGrBAwoaE73DVD5hqsfbANW6SGhGPMP7bx8H6M77SeQ
gLw7VB7UU3qwCbOpXG0HLoKdhFubK5Z8J49exRkoqRuJQ3I3myPVuA==
`pragma protect end_protected
